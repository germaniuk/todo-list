import 'core-js/es6';
// для поддержки Reflect Api
import 'core-js/es7/reflect';
// zone используется angular
import 'zone.js/dist/zone'